##---------------------------------------------------------------------------------------###
##              Procedure d'installation et d'utilsation de vdbench en 10 étapes         ###
##                         Pour toute question : cyril@purestorage.com                   ###
##                    La solution ici proposée n'engage en rien Purestorage              ###
##---------------------------------------------------------------------------------------###
1/ Ouvrir et installer la tarball fournie :
   $ mkdir -p /root/AFA/
   $ cd /root/AFA/ 
   $ tar -xvf vdbench-Toolkit-2018files.tar
   L'arborescence pure_test qui va être extraite contient les deux répertoires suivants :
   - vdb-longRunsProfiles  --> aging sur plusieurs jours
   - vdb-shortRunsProfiles --> ideal pour valider les stress
   Pour plus de simplicité quant à l'utilsation des scripts fournis,
   recopier le contenu de l'un des répertoires fournis sour /root/AFA/pure_test ou
   toute arborescence positionnée dans la variable HOMEKIT des scripts :
   - startIDC-Stress
   - evalTest
   - do_test
   - do_multiple_tests
   
   Les fichiers et dossiers suivants seront disponibles à l'extraction :
   do_multiple_tests, do_test, mon2, Profiles, run_evalStress, startIDC-Stress, vdbLogs

2/ Recopier le fichier mon2 de sorte qu'il soit disponible dans le PATH user
   Sous Linux, il est possible d'utiliser /usr/local/bin comme cible

3/ Les fichiers de configuration (sous le répertoire Profiles) ont été créés pour solliciter
   deux machines de stress de façon la plus réaliste possible.
   Ces fichiers resteront sur la machine de commande et pourront etre modifiés pour gérer
   plus de machines de stress ou de devices si cela est jugé nécessaire.
   - le fichier storage_definition.vdb definit les devices à stresser par machine
   - le fichier host_definition.vdb permet de renseigner les machines à stresser

4/ Idéalement, la résolution de nom des hosts sera active (DNS ou en local via /etc/hosts)

5/ les ports TCP 5570 à 5578 devront être ouverts pour que les communications entre la
   machine de commande et jusque 8 machines de stress soit possible
   Sous CentOS, et par machine participant aux stress :
   # firewall-cmd --get-active-zones
   # firewall-cmd --zone=public --add-port=5570-5578/tcp --permanent
   # firewall-cmd --reload

6/ La connexion vers les machines de stress devra pouvoir se faire sans préciser de mdp
   [root@vdb-main ~]# ssh-keygen
   [root@vdb-main ~]# ssh-copy-id root@vdb-001
   [root@vdb-main ~]# ssh-copy-id root@vdb-002

7/ Le serveur de temps doit être identique sur TOUTES les machines participant au stress :
   Sous CentOS :
   # yum -y install ntpdate
   # ntpdate ntp.polytechnique.fr
   # systemctl enable ntpdate

8/ La JVM java doit etre déployée sur les machines participant aux stress :
   http://www.oracle.com/technetwork/java/javase/downloads/index.html
   # mkdir -p /usr/java # (minimal distro only)
   # cd /usr/java
   # gunzip jdk-9.0.4_linux-x64_bin.tar.gz
   # tar -xvf jdk-9.0.4_linux-x64_bin.tar
   # ln -s /usr/java/jdk-9.0.4 /usr/java/latest
   # ln -s /usr/java/latest /usr/java/default
   
9/ Le package vdbench doit etre déployé sur les machines participant aux stress :
   http://www.oracle.com/technetwork/server-storage/vdbench-downloads-1901681.html
   Pour plus de facilité, l'outil devra être accessible via  /root/vdbench/vdbench
   Afin d’apporter plus de stabilité aux tests à réaliser, il est nécessaire de modifier
   le contenu du script de démarrage vdbench comme suit :
   ---
   #!/bin/bash
   dir=`dirname $0`
   cp=$dir/:$dir/classes:$dir/vdbench.jar
   set java=/usr/java/latest/bin/java
   if [ "$1" == "SlaveJvm" ]; then
      $java -client -Xmx2048m -Xms512m -cp $cp Vdb.SlaveJvm $*
      exit $?
   else
      $java -client -Xmx4096m -Xms2048m -cp $cp Vdb.Vdbmain $*
      exit $?
   fi
   ---

10/ les stress peuvent être lancés de deux façon :
   - de façon unitaire
     -> en utilisant une à une les commandes lancées dans le script startIDC-Stress
        do_test
        do_multiple_test
     -> en lançant directement vdbench avec comme argument les fichiers de configuration 
        .vdb fournis
        Exemple: $ vdbench -f ./Profiles/oracle_workload.vdb
   - de façon automatisée en lançant le script startIDC-Stress ou run_evalStress

A propos des résultats :
En mode automatisé, les logs seront regroupés sous le répertoire vdbLogs
Les fichiers et répertoires suivants seront créés :
- fic/ console_nomFichierVdb_Phase : traces vdbench avec erreurs éventuelles et suivi des IOs
- fic/ pure_test_nomDePhase.out : trace timing debut de tir et fin de tir
- Rep/ out_nomFichierVdb-Phase  : répertoire de logs vdbench (html, etc)

